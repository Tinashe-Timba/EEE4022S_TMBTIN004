function [rdMap_A_clutterRemoved, rdMap_B_clutterRemoved, clutterMap_A, clutterMap_B, previousFrame_A, previousFrame_B] = removeClutterMagnitude(rdMap_A, rdMap_B, previousFrame_A, previousFrame_B, clutterMap_A, clutterMap_B, method, initial_alpha, dynamic_alpha_enabled, alpha_min, alpha_max, frameIdx, alpha,env1,env2)
    % Get the size of the input range-Doppler maps
    [numVelBins, numRangeBins] = size(rdMap_A);

    % Take magnitude of the input range-Doppler maps (to work with power levels)
    rdMap_A_mag = abs(rdMap_A);
    rdMap_B_mag = abs(rdMap_B);

    if isempty(clutterMap_A) || ~isequal(size(clutterMap_A), size(rdMap_A_mag))
        clutterMap_A = zeros(numVelBins, numRangeBins);
    end
    if isempty(clutterMap_B) || ~isequal(size(clutterMap_B), size(rdMap_B_mag))
        clutterMap_B = zeros(numVelBins, numRangeBins);
    end

    if isempty(previousFrame_A) || ~isequal(size(previousFrame_A), size(rdMap_A_mag))
        previousFrame_A = rdMap_A_mag; % Initialize with the current frame
    end
    if isempty(previousFrame_B) || ~isequal(size(previousFrame_B), size(rdMap_B_mag))
        previousFrame_B = rdMap_B_mag; % Initialize with the current frame
    end

    % Initialize clutter-removed range-Doppler maps
    rdMap_A_clutterRemoved = zeros(numVelBins, numRangeBins);
    rdMap_B_clutterRemoved = zeros(numVelBins, numRangeBins);

    % Skip clutter removal for the first frame, 
    if frameIdx == 1
        rdMap_A_clutterRemoved = rdMap_A_mag;
        rdMap_B_clutterRemoved = rdMap_B_mag;
        previousFrame_A = rdMap_A_mag;
        previousFrame_B = rdMap_B_mag;
        env1=rdMap_A_mag;
        env2=rdMap_B_mag;
        return;
    end

    % Apply clutter removal based on the selected method
    switch method
        case 'adaptive'
            % Adaptive Clutter Map for rdMap_A (using magnitudes)
            if dynamic_alpha_enabled
                frame_variance_A = var(rdMap_A_mag(:));
                alpha = min(max(initial_alpha * (frame_variance_A / mean(rdMap_A_mag(:))), alpha_min), alpha_max);
            else
                alpha = initial_alpha;
            end
            clutterMap_A = alpha * clutterMap_A + (1 - alpha) * rdMap_A_mag;
            rdMap_A_clutterRemoved = rdMap_A_mag - clutterMap_A;

            % Adaptive Clutter Map for rdMap_B (using magnitudes)
            if dynamic_alpha_enabled
                frame_variance_B = var(rdMap_B_mag(:));
                alpha = min(max(initial_alpha * (frame_variance_B / mean(rdMap_B_mag(:))), alpha_min), alpha_max);
            else
                alpha = initial_alpha;
            end
            clutterMap_B = alpha * clutterMap_B + (1 - alpha) * rdMap_B_mag;
            rdMap_B_clutterRemoved = rdMap_B_mag - clutterMap_B;

        case 'frame_subtraction'
            %Frame Subtraction for rdMap_A (using magnitudes)
            rdMap_A_clutterRemoved = rdMap_A_mag - previousFrame_A;
            previousFrame_A = rdMap_A_mag;
              % rdMap_A_clutterRemoved = rdMap_A_mag - env1;
            %Frame Subtraction for rdMap_B (using magnitudes)
            rdMap_B_clutterRemoved = rdMap_B_mag - previousFrame_B;
            previousFrame_B = rdMap_B_mag;
           % rdMap_B_clutterRemoved = rdMap_B_mag - env2;
        case 'frame_mean_subtraction'
            % Frame Mean Subtraction for rdMap_A (using magnitudes)
            frameMean_A = mean(rdMap_A_mag, 2); % Mean across the range bins
            rdMap_A_clutterRemoved = rdMap_A_mag - repmat(frameMean_A, 1, numRangeBins);

            % Frame Mean Subtraction for rdMap_B (using magnitudes)
            frameMean_B = mean(rdMap_B_mag, 2); % Mean across the range bins
            rdMap_B_clutterRemoved = rdMap_B_mag - repmat(frameMean_B, 1, numRangeBins);
    end
end
