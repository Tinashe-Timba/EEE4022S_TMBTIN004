% Function to compute the Doppler Map from the concatenated Range Map
function rangeDopplerMap = computeDopplerMap(RangeMap, zeroPadLengthDoppler)
    hannWindow = hann(size(RangeMap, 1));
    RangeMap = RangeMap .* hannWindow;
    % Apply zero-padding if required
    %RangeMap= [RangeMap; zeros(zeroPadLengthDoppler - size(RangeMap, 1), size(RangeMap, 2))];
    
    % Perform the Doppler FFT
    rangeDopplerMap = fftshift(fft(RangeMap(1:end, 1:size(RangeMap, 2)/2), zeroPadLengthDoppler, 1), 1);  % FFT along the first dimension (Doppler)
end
