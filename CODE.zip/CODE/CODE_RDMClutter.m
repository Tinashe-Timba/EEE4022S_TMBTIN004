% Clear workspace and close all figures
%CODE TO CHECK OUTPUT BEFORE MAIN PROCESSING AND TO PROCESS VALIDATION
%PLOTS
clear all;
close all;

% Specify the HDF5 filenames 
filename_ch1 = 'one/EX3_ch1.hdf5'; % Channel 1 data11
filename_ch2 = 'one/EX3_ch2.hdf5'; % Channel 2 data

%% 

% FMCW Radar parameters
carrierFrequency = 9.5e9; % Hz, 9.5 GHz carrier frequency
c = 3e8; % Speed of light in meters per second
wavelength = c / carrierFrequency; % Wavelength in meters
antennaDistance = 2.1e-2; % Distance between antennas in meters

rangeBinSize = 1.875; % meters
SRI = 0.0016; % seconds (chirp repetition interval)
numADCSamples = 1024; % Number of ADC samples per chirp 
maxRange = 960.0; % meters
maxDopplerFreq = 625.0; % Hz
maxVelocity = 9.827044025157234; % m/s, calculated based on 9.5 GHz carrier frequency
dopplerBinSize =0.03838689072327044; % Hz
limit =110 ; % Limit3 the range axis to 100 meters

% Derived parameters
PRF = 1 / SRI; % Pulse Repetition Frequency
zeroPadLengthRange = 1024; % Zero-padding length for Range FFT
zeroPadLengthDoppler = 256; % Zero-padding length for Doppler FFT
numChirps = 256;
numSamples = 1024;
%% MYCFAR PARAMETERS
% Define CFAR parameters
numGuardCells = 2;
numReferenceCells = 5;
desiredPFA = 1e-6;  % Example PFA (adjust based on your needs)
%% ADAPTIVE CLUTTER MAP PARAMETERS

initial_alpha = 0.3;  % Initial smoothing factor (0 < alpha < 1)
dynamic_alpha_enabled = true;  % Set to true to enable dynamic adjustment
alpha_min = 0.8;  % Minimum alpha value
alpha_max = 0.9;   % Maximum alpha value
alpha=0.5;

%% %  MMwAVE CFAR function on  rangeDopplerMap
cfar_range_guard = 3;
cfar_range_training = 5;
cfar_doppler_guard = 3;
cfar_doppler_training = 5;
cfar_pfa = 1e-6;
cfar_threshold = 5;
minDopplerVelocity = 0.05;  % Lower to detect slow-moving targets

%% % Initialize clutter maps, previous frames, and frame averages

method = 'frame_subtraction'; % Choose between 'adaptive', 'frame_subtraction', 'frame_mean_subtraction'
previousFrame_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
previousFrame_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
clutterMap_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
clutterMap_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
frameMean_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
frameMean_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
env1=zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
env2=zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
%% 
clutterRemovalEnabledOnRangeMap = false;  %
% method = 'frame_subtraction'; % Choose between 'adaptive', 'frame_subtraction', 'frame_mean_subtraction'
% previousFrame_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange);
% previousFrame_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange);
% clutterMap_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange);
% clutterMap_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange);
% frameMean_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange);
% frameMean_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange);
% env1=zeros(zeroPadLengthDoppler,zeroPadLengthRange);
% env2=zeros(zeroPadLengthDoppler,zeroPadLengthRange);
%% 


% Load information about the datasets for both channels
info_ch1 = h5info(filename_ch1);
info_ch2 = h5info(filename_ch2);
datasets_ch1 = {info_ch1.Datasets.Name};
datasets_ch2 = {info_ch2.Datasets.Name};

% Sort dataset names numerically
datasets_ch1 = sortNumericDatasetNames(datasets_ch1);
datasets_ch2 = sortNumericDatasetNames(datasets_ch2);
TotalFrames = length(datasets_ch1); % Number of frames

% Initialize an array to hold AoA estimates for each frame
AoA_estimates = zeros(1, TotalFrames);
%% MICRO DOPPLER PARAMETERS

% Define radar parameters
p.nChirps = 256;
p.nFrames = TotalFrames;
p.nSamples = 1024;
p.PRF=PRF;
p.zeroPadLengthDoppler=zeroPadLengthDoppler;
p.wavelength=wavelength;
p.window_size = 256;
p.overlap = 0.99;
p.pad_size =0;
p.range_bin=256;
p.w_range = 'hann';
p.w_doppler = 'hamming';
%range_bins=10n
data_all_frames = zeros(numChirps, numADCSamples, TotalFrames);
refined_cfar_matrix = zeros(zeroPadLengthDoppler, zeroPadLengthRange/2, TotalFrames);

%% 

% Initialize arrays to store preprocessed frames
preprocessed_data_ch1 = [];
preprocessed_data_ch2 = [];

for frameIdx = 1:TotalFrames
    % Load the current dataset (frame) for Channel 1 and Channel 2
    datasetName_ch1 = datasets_ch1{frameIdx};
    datasetName_ch2 = datasets_ch2{frameIdx};
    data_ch1 = h5read(filename_ch1, ['/' datasetName_ch1]).';
    data_ch2 = h5read(filename_ch2, ['/' datasetName_ch2]).';
    
    % Check if the data size is 512x1024 (combined two frames)
    if size(data_ch1, 1) == 512
        % Split into two separate frames of 256x1024
        data_ch1_frame1 = data_ch1(1:256, :);
        data_ch1_frame2 = data_ch1(257:end, :);
        data_ch2_frame1 = data_ch2(1:256, :);
        data_ch2_frame2 = data_ch2(257:end, :);

        % Append the split frames to the preprocessed data array
        preprocessed_data_ch1 = cat(3, preprocessed_data_ch1, data_ch1_frame1, data_ch1_frame2);
        preprocessed_data_ch2 = cat(3, preprocessed_data_ch2, data_ch2_frame1, data_ch2_frame2);

    elseif size(data_ch1, 1) <= 256
        % If the frame is already 256x1024 or smaller, add it directly
        % Pad the frame if necessary (e.g., if it's smaller than 256x1024)
        data_ch1_padded = padarray(data_ch1, [256 - size(data_ch1, 1), 0], 0, 'post');
        data_ch2_padded = padarray(data_ch2, [256 - size(data_ch2, 1), 0], 0, 'post');

        % Append the padded frames to the preprocessed data array
        preprocessed_data_ch1 = cat(3, preprocessed_data_ch1, data_ch1_padded);
        preprocessed_data_ch2 = cat(3, preprocessed_data_ch2, data_ch2_padded);

    elseif size(data_ch1, 1) == 511
        % Handle odd-sized frames like 511x1024 by padding them to 512
        data_ch1_padded = padarray(data_ch1, [1, 0], 0, 'post');
        data_ch2_padded = padarray(data_ch2, [1, 0], 0, 'post');

        % Split into two frames of size 256x1024 after padding
        data_ch1_frame1 = data_ch1_padded(1:256, :);
        data_ch1_frame2 = data_ch1_padded(257:end, :);
        data_ch2_frame1 = data_ch2_padded(1:256, :);
        data_ch2_frame2 = data_ch2_padded(257:end, :);

        % Append the split frames to the preprocessed data array
        preprocessed_data_ch1 = cat(3, preprocessed_data_ch1, data_ch1_frame1, data_ch1_frame2);
        preprocessed_data_ch2 = cat(3, preprocessed_data_ch2, data_ch2_frame1, data_ch2_frame2);

    else
        % Handle any unexpected frame sizes that are not covered
        error('Unexpected frame size: %d-by-%d', size(data_ch1, 1), size(data_ch1, 2));
    end
end

% Update the TotalFrames variable to reflect the actual number of preprocessed frames
TotalFrames = size(preprocessed_data_ch1, 3);
angle_matrix_all_frames = zeros(256, 512, TotalFrames);


%% 

% Initialize the overall frequency-time matrix to accumulate the results
%overall_frequency_time_matrix = [];
for frameIdx = 1:50

    % % Load the current dataset (frame) for Channel 1 and Channel 2
    % datasetName_ch1 = datasets_ch1{frameIdx};
    % datasetName_ch2 = datasets_ch2{frameIdx};
    % data_ch1 = h5read(filename_ch1, ['/' datasetName_ch1]).';
    % data_ch2 = h5read(filename_ch2, ['/' datasetName_ch2]).';

 % Use preprocessed data for Channel 1 and Channel 2 512*1024
    IQ_A = extractIQData(preprocessed_data_ch1(:,:,frameIdx), 16); % Channel 1
    IQ_B = extractIQData(preprocessed_data_ch2(:,:,frameIdx), 16); % Channel 2



    % % Extract IQ data for both channels
    % IQ_A = extractIQData(data_ch1, 16); % Channel 1
    % IQ_B = extractIQData(data_ch2, 16); % Channel 2
   
    % Combine the IQ data from both channels to reduce SNR
    combinedIQ = (IQ_A+IQ_B);
    data_all_frames(:, :, frameIdx) =IQ_A+IQ_B;

    %RANGE FFT
    
   rangeMap_A=computeRangeMap(IQ_A, zeroPadLengthRange);
    
   rangeMap_B=computeRangeMap(IQ_B, zeroPadLengthRange);
   rangeMap_combined = computeRangeMap(combinedIQ, zeroPadLengthRange);

   % rangeMap_A=computeRangeMapSliding(IQ_A, zeroPadLengthRange,512,32);
    
   % rangeMap_B=computeRangeMapSliding(IQ_B, zeroPadLengthRange,512,32);


    % Clutter Removal on Range Map (if enabled)
    if clutterRemovalEnabledOnRangeMap
        [rangeMap_A, rangeMap_B, previousFrame_A, previousFrame_B, clutterMap_A, clutterMap_B] = removeClutterR(rangeMap_A, rangeMap_B, previousFrame_A, previousFrame_B, clutterMap_A, clutterMap_B, method, initial_alpha, dynamic_alpha_enabled, alpha_min, alpha_max, frameIdx, alpha);
    end


   %RANGE DOPPLER MAPS
  
    [numChirpsInFrame, numRangeBins] = size(rangeMap_combined);

    % RANGE DOPPLER MAP
    rangeDopplerMap = computeDopplerMap(rangeMap_combined, zeroPadLengthDoppler);
    rangeDopplerMap_a=computeDopplerMap(rangeMap_A, zeroPadLengthDoppler);
    rangeDopplerMap_b=computeDopplerMap(rangeMap_B, zeroPadLengthDoppler);
    % rangeDopplerMap = computeDopplerMapSliding(rangeMap_combined, zeroPadLengthDoppler,128,32);
    % rangeDopplerMap_a=computeDopplerMapSliding(rangeMap_A, zeroPadLengthDoppler,128,32);
    % rangeDopplerMap_b=computeDopplerMapSliding(rangeMap_B, zeroPadLengthDoppler,128,32);

    %CLUTTER REMOVAL
 [rangeDopplerMap_A, rangeDopplerMap_B, clutterMap_A, clutterMap_B, previousFrame_A, previousFrame_B] =  removeClutterMagnitude(rangeDopplerMap_a, rangeDopplerMap_b, previousFrame_A, previousFrame_B, clutterMap_A, clutterMap_B, method, initial_alpha, dynamic_alpha_enabled, alpha_min, alpha_max, frameIdx, alpha,env1,env2);
     

    %CFAR TRAGET DETECTION
    clutterRemovedMap= rangeDopplerMap_A+ (rangeDopplerMap_B);
      %clutterRemovedMap =rangeDopplerMap_a+ (rangeDopplerMap_b);
    velocityAxis = (-size(rangeDopplerMap, 1) / 2 : size(rangeDopplerMap, 1) / 2 - 1) *0.03838689072327044;

   % [CFAR_map, detectedTargets] = detectTargetsWithCFAR(clutterRemovedMap, desiredPFA, numGuardCells, numReferenceCells, velocityAxis);
    detections = cfar(clutterRemovedMap, cfar_range_guard, cfar_range_training, cfar_doppler_guard, cfar_doppler_training, cfar_pfa, cfar_threshold, velocityAxis, minDopplerVelocity, rangeBinSize,110);

    % Clean up the detections if necessary
    radius =2;  % Example radiu
   [refined_cfar, centroid_list] = clean_cfar(detections, radius,(clutterRemovedMap));
   refined_cfar_matrix(:, :, frameIdx) =refined_cfar;
   %PLOT WITH MY CFAR
  % plotRangeDopplerMapSequence(clutterRemovedMap, frameIdx, maxVelocity, rangeBinSize, limit, PRF, zeroPadLengthDoppler, zeroPadLengthRange, wavelength,detectedTargets,clutterMap);
  %PLOT WITH DETECTIONS MMWAVE
   %plotRangeDopplerMapSequence(clutterRemovedMap, frameIdx, maxVelocity, rangeBinSize, limit, PRF, zeroPadLengthDoppler, zeroPadLengthRange, wavelength,detections,clutterMap);
   %PLOT WITH REFINED CFAR
%plotRangeDopplerMapSequence(clutterRemovedMap, frameIdx, maxVelocity, rangeBinSize, limit, PRF, zeroPadLengthDoppler, zeroPadLengthRange, wavelength,refined_cfar);
    
 






   %AOA USING IQ DATA
     %AoA_estimates(frameIdx) = estimateAoA(IQ_A, IQ_B, carrierFrequency, antennaDistance);
  
   %RANGE ANGLE PLOT 
     %[rangeAngleMap,angleMatrix]=computeRangeAngleMapWithCFAR(rangeDopplerMap_A,rangeDopplerMap_B, zeroPadLengthRange, zeroPadLengthDoppler, carrierFrequency, antennaDistance,detectedTargets);
    [rangeAngleMap,angleMatrix]=computeRangeAngleMapWithCFAR(rangeDopplerMap_a,rangeDopplerMap_b, zeroPadLengthRange, zeroPadLengthDoppler, carrierFrequency, antennaDistance,refined_cfar);
   %plotRangeAngleMap(rangeAngleMap, rangeBinSize, frameIdx);
   % Store the angle matrix for validation
    angle_matrix_all_frames(:, :, frameIdx) = angleMatrix;

   %plotPolarRangeAngleMovement(angleMatrix, rangeAngleMap, rangeBinSize, frameIdx,100 )
    %plotRangeAngleMap2(angleMatrix, rangeBinSize, frameIdx)
    
end



%% micro doppler





range_bin_selection = 1:91;  %

v_min= 0;  
v_max =5;   


%frequency_time = spectrogram_v(data_all_frames, p, v_min, v_max, range_bin_selection);

frequency_time = spectrogram_c(data_all_frames, p, v_min, v_max, range_bin_selection, refined_cfar_matrix);


% Find the global maximum value in the entire frequency_time matrix
global_max_val = max(abs(frequency_time(:)));  % Maximum value of the entire matrix

% Normalize each column of the matrix by the global maximum value
if global_max_val ~= 0
    frequency_time = frequency_time / global_max_val;  % Normalize the entire matrix
end

% Plotting the micro-Doppler spectrogram
N = size(frequency_time, 1);
M = size(frequency_time, 2);
t_sweep = 0.0016;  % Sweep time (example value)
fs = 1 / t_sweep;
hop = p.window_size - floor(p.overlap * p.window_size);


time_axis = (p.window_size / 2 : hop : p.window_size / 2 + (M - 1) * hop) / fs;
frequency_axis = (N/2:-1:-(N/2)-1) *dopplerBinSize;

% Plot
figure;
imagesc(time_axis, frequency_axis,(20 * log10(abs(frequency_time)))-max(max(20 * log10(abs(frequency_time)))));
title('Micro-Doppler Spectrogram');
xlabel('Time [s]');
ylabel('Frequency [Hz]');
colorbar;
caxis([-100 20]);  % 
colormap('jet');
axis xy;  % Ensure positive velocity is on top

%% 
truth_angle = 20;  % Target truth angle
chirp_duration = 0.0016;  % Duration of a single chirp in seconds
num_chirps_per_frame = 256;  % Number of chirps per frame
frame_duration = num_chirps_per_frame * chirp_duration;  % Duration of one frame in seconds

% Initialize arrays to store validation results
measured_angles = [];  % Store all measured angles across frames
frame_numbers = [];  % Will be used to calculate time

% Extract the measured angles from each frame (use a specific range bin or average over bins)
for frameIdx = 1:TotalFrames
    current_angle_matrix = angle_matrix_all_frames(:, :, frameIdx);

    % Extract only the non-zero angles from the current angle matrix (in degrees, as in the plot function)
    non_zero_angles_deg = current_angle_matrix(current_angle_matrix ~= 0);

    % Filter angles: ignore angles less than 20° and greater than 40°
    valid_angles_deg = non_zero_angles_deg(non_zero_angles_deg >= 20 & non_zero_angles_deg <= 40);

    % Check if there are any valid non-zero angles to work with
    if ~isempty(valid_angles_deg)
        % Calculate the mean of the valid non-zero angles for this frame
        measured_angle_frame = mean(valid_angles_deg);  % Mean angle in degrees
    else
        % If no valid angles, handle the case (e.g., by setting NaN or a default value)
        measured_angle_frame = NaN;  % You could also use 0 or another value
    end

    % Store the results for validation
    measured_angles = [measured_angles, measured_angle_frame];
    frame_numbers = [frame_numbers, frameIdx];  % Store frame number for time calculation
end

% Remove NaN values from the measured angles and frame numbers
valid_indices = ~isnan(measured_angles);
measured_angles = measured_angles(valid_indices);
frame_numbers = frame_numbers(valid_indices);

% Calculate time for each frame
time_seconds = frame_numbers * frame_duration;  % Convert frame numbers to time in seconds

% Linear regression (fit line of best fit)
p = polyfit(time_seconds, measured_angles, 1);  % Perform linear regression
best_fit = polyval(p, time_seconds);  % Calculate best fit line

% Plot truth, measured data, and best fit line
figure;
plot(time_seconds, truth_angle * ones(size(time_seconds)), 'k-', 'LineWidth', 2);  % Truth line (20°)
hold on;
scatter(time_seconds, measured_angles, 'r');  % Measured angles
plot(time_seconds, best_fit, 'b-', 'LineWidth', 2);  % Best fit line
legend('Truth (20°)', 'Measured Angles', 'Line of Best Fit');
title('Angle Validation Over Time');
xlabel('Time (s)');  % Now showing time instead of frame number
ylabel('Angle (degrees)');
ylim([0 30])  % Adjust y-axis limits
grid on;
hold off;

% Calculate accuracy (Mean Absolute Error and RMSE)
mae = mean(abs(measured_angles - truth_angle));  % Mean Absolute Error
rmse = sqrt(mean((measured_angles - truth_angle).^2));  % Root Mean Square Error

% Calculate the average measured angle
avg_measured_angle = mean(measured_angles);

% Display the result
fprintf('Average Measured Angle: %.2f degrees\n', avg_measured_angle);

% Display results
disp(['Mean Absolute Error: ', num2str(mae)]);
disp(['Root Mean Square Error: ', num2str(rmse)]);

%%
% truth_angle = 0;  % Target heading towards radar at 0 degrees
% 
% % Radar parameters for time calculation
% chirp_duration = 0.0016;  % Duration of a single chirp in seconds
% num_chirps_per_frame = 256;  % Number of chirps per frame
% frame_duration = num_chirps_per_frame * chirp_duration;  % Duration of one frame in seconds
% 
% % Initialize arrays to store validation results
% measured_angles = [];  % Store all measured angles across frames
% frame_numbers = [];  % Will be converted to time later
% 
% % Extract the measured angles from each frame
% for frameIdx = 1:TotalFrames
%     current_angle_matrix = angle_matrix_all_frames(:, :, frameIdx);
% 
%     % Flatten the angle matrix into a single vector
%     all_angles_deg = current_angle_matrix(:);
% 
%     % Filter angles: keep angles between -10° and 10° (focus on angles near 0°)
%     valid_angles_deg = all_angles_deg;
% 
%     % Check if there are any valid angles to work with
%     if ~isempty(valid_angles_deg)
%         % Calculate the mean of the valid angles for this frame
%         measured_angle_frame = mean(valid_angles_deg);  % Mean angle in degrees
%     else
%         % If no valid angles, handle the case (e.g., by setting NaN or a default value)
%         measured_angle_frame = NaN;
%     end
% 
%     % Store the results for validation
%     measured_angles = [measured_angles, measured_angle_frame];
%     frame_numbers = [frame_numbers, frameIdx];  % Store frame number (for time calculation)
% end
% 
% % Remove NaN values from the measured angles and frame numbers
% valid_indices = ~isnan(measured_angles);
% measured_angles = measured_angles(valid_indices);
% frame_numbers = frame_numbers(valid_indices);
% 
% % Calculate time for each frame
% time_seconds = frame_numbers * frame_duration;  % Convert frame numbers to time in seconds
% 
% % Linear regression (fit line of best fit)
% p = polyfit(time_seconds, measured_angles, 1);  % Perform linear regression
% best_fit = polyval(p, time_seconds);  % Calculate best fit line
% 
% % Plot truth, measured data, and best fit line
% figure;
% plot(time_seconds, truth_angle * ones(size(time_seconds)), 'k-', 'LineWidth', 2);  % Truth line (0°)
% hold on;
% scatter(time_seconds, measured_angles, 'r');  % Measured angles
% plot(time_seconds, best_fit, 'b-', 'LineWidth', 2);  % Best fit line
% legend('Truth (0°)', 'Measured Angles', 'Line of Best Fit');
% title('Angle Validation for Target at 0° Over Time');
% xlabel('Time (s)');  % Now showing time instead of frame number
% ylabel('Angle (degrees)');
% grid on;
% hold off;
% 
% % Calculate accuracy (Mean Absolute Error and RMSE)
% mae = mean(abs(measured_angles - truth_angle));  % Mean Absolute Error
% rmse = sqrt(mean((measured_angles - truth_angle).^2));  % Root Mean Square Error
% 
% % Calculate the average measured angle
% avg_measured_angle = mean(measured_angles);
% 
% % Display the result
% fprintf('Average Measured Angle: %.2f degrees\n', avg_measured_angle);
% 
% % Display results
% disp(['Mean Absolute Error: ', num2str(mae)]);
% disp(['Root Mean Square Error: ', num2str(rmse)]);



%% Radar Velocity Extraction fro
% Parameters for velocity extraction based on Doppler bins
N = size(refined_cfar_matrix, 1);  % Number of Doppler bins
dopplerBinSize = 0.03838689072327044;  % Doppler bin size
max_velocity = 9.827044025157234 / 2;  % Nyquist velocity (half of the max unambiguous velocity)

% Calculate velocity axis from Doppler bins
velocity_axis = (N/2:-1:-(N/2)-1) * dopplerBinSize;  % Convert Doppler bins to velocities

% Initialize arrays to store radar velocities
radar_velocities = [];
filtered_radar_velocities = [];  % Filtered radar velocities for impossible velocities
frame_numbers = [];

% Define velocity threshold for filtering impossible values
impossible_velocity_threshold = 6;  % Example: Set a threshold of 7 m/s

% Loop through each frame in the CFAR results
for frameIdx = 1:size(refined_cfar_matrix, 3)  % Using the third dimension for frames
    
    % Get CFAR detections for this frame
    cfar_detections = refined_cfar_matrix(:, :, frameIdx);  % CFAR matrix for the current frame
    
    % Check if there are any detections in the current frame
    if sum(cfar_detections(:)) == 0
        disp(['Frame ', num2str(frameIdx), ' has no CFAR detections.']);
        continue;
    end
    
    % Identify non-zero CFAR detections (targets)
    [doppler_bins, range_bins] = find(cfar_detections > 0);
    
    % Ensure valid detections exist in the frame
    if isempty(doppler_bins)
        disp(['Frame ', num2str(frameIdx), ' has no valid CFAR detections after Doppler extraction.']);
        continue;
    end
    
    % Convert Doppler bins to velocities based on frequency axis
    detected_velocities = velocity_axis(doppler_bins);
    
    % Unwrap the velocities
    unwrapped_velocities = detected_velocities;
    unwrapped_velocities(detected_velocities < 0) = detected_velocities(detected_velocities < 0) + 2 * max_velocity;
    
    % Filter velocities within a reasonable range
    v_min = 0;  % Minimum velocity in m/s
    v_max = 10;   % Maximum velocity in m/s
    valid_velocities = unwrapped_velocities(unwrapped_velocities >= v_min & unwrapped_velocities <= v_max);
    
    % Skip frames with no valid velocities to avoid concatenation errors
    if isempty(valid_velocities)
        disp(['Frame ', num2str(frameIdx), ' has no valid velocities after filtering.']);
        continue;
    end
    
    % Calculate the mean velocity for this frame
    mean_velocity_frame = mean(valid_velocities);
    
    % Apply additional filtering to remove impossible velocities beyond the threshold
    if mean_velocity_frame <= impossible_velocity_threshold
        filtered_velocity_frame = mean_velocity_frame;
    else
        filtered_velocity_frame = NaN;  % Mark impossible velocities as NaN
    end
    
    % Store the radar velocity and corresponding frame number
    radar_velocities = [radar_velocities, mean_velocity_frame];
    filtered_radar_velocities = [filtered_radar_velocities, filtered_velocity_frame];  % Store filtered velocity
    frame_numbers = [frame_numbers, frameIdx];  % Store corresponding frame index
end


%% Time Synchronization and Plotting

%% Time Synchronization and Plotting
% Constants
chirp_duration = 0.0016;  % Duration of a single chirp in seconds
num_chirps_per_frame = 256;  % Number of chirps per frame
frame_duration = num_chirps_per_frame * chirp_duration;  % Duration of one frame in seconds

% Calculate time for each radar frame in seconds
radar_time = frame_numbers * frame_duration;  % Convert frame numbers to time (in seconds)

% Convert GPS time data (datetime) to seconds relative to the first GPS timestamp
gps_time_seconds = seconds(time_data - time_data(1));

% Ensure GPS time ends at the same time as radar time
max_radar_time = radar_time(end);  % Find the last radar time
gps_time_seconds = gps_time_seconds(gps_time_seconds <= max_radar_time);
speed_mps = speed_mps(gps_time_seconds <= max_radar_time);

% Remove duplicate times in GPS data
[gps_time_seconds_unique, unique_idx] = unique(gps_time_seconds);
speed_mps_unique = speed_mps(unique_idx);

% Interpolate GPS velocities onto radar time points
interpolated_gps_velocity = interp1(gps_time_seconds_unique, speed_mps_unique, radar_time, 'linear', 'extrap');

% Apply a moving average filter to smooth the radar velocities
window_size = 5;  % Define the window size for the moving average filter (adjust as needed)
smoothed_radar_velocities = movmean(radar_velocities, window_size);

% Plot GPS and radar velocities side by side
figure;

% First subplot: GPS Velocities
subplot(2,1,1);  % Two rows, one column, first subplot
plot(gps_time_seconds, speed_mps, 'r-', 'LineWidth', 1.5);  % GPS speed in m/s
title('GPS Velocity Over Time');
xlabel('Time (s)');
ylabel('Velocity (m/s)');
ylim([0 9.827044025157234]);  % Set Y-axis limit from 0 to 8
grid on;

% Second subplot: Radar Velocities with smoothed velocities
subplot(2,1,2);  % Two rows, one column, second subplot

% Plot the unfiltered radar velocities
plot(radar_time, radar_velocities, 'b', 'LineWidth', 1.5);  % Original radar velocity
hold on;

% Plot the smoothed radar velocities using the moving average filter
plot(radar_time, smoothed_radar_velocities, 'g', 'LineWidth', 1.5);  % Smoothed radar velocity

% Customize the plot
title('Radar Estimated Velocity Over Time');
xlabel('Time (s)');
ylabel('Velocity (m/s)');
ylim([0 9.827044025157234]);  % Set Y-axis limit from 0 to 8
legend('Original Radar Velocity', 'Smoothed Radar Velocity');  % Add a legend
grid on;

% Set overall figure title
sgtitle('Comparison of GPS and Radar Velocities ');
;
