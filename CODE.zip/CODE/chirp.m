% Parameters for the chirp signal
A_tx = 1;           % Amplitude of the transmitted signal
f_c = 5e9;          % Carrier frequency (5 GHz)
B = 200e6;          % Bandwidth of the chirp (200 MHz)
T = 1e-6;           % Chirp duration (1 microsecond)
t = linspace(0, T, 1000);  % Time array from 0 to T with 1000 samples

% Compute the chirp signal
s_tx = A_tx * cos(2 * pi * (f_c * t + (B / T) * (t.^2) / 2));

% Plot the chirp signal
figure;
plot(t * 1e6, s_tx);  % Plot time in microseconds
title('Chirp Signal');
xlabel('Time (\mus)');
ylabel('Amplitude');
grid on;
