function detections = cfar(range_doppler_map, cfar_range_guard, cfar_range_training, cfar_doppler_guard, cfar_doppler_training, cfar_pfa, cfar_threshold, velocityAxis, minDopplerVelocity, rangeBinSize, maxRange)
    % Performs CFAR detection on range-doppler map using 2D convolution in FFT domain
    % and applies a detection range limit

    % Create the CFAR training kernel
    p_kernel = ones(1 + 2 * (cfar_range_guard + cfar_range_training), ...
                    1 + 2 * (cfar_doppler_guard + cfar_doppler_training));
    
    % Create guard cells by zeroing out the central region
    guard = zeros(2 * cfar_range_guard + 1, 2 * cfar_doppler_guard + 1);
    p_kernel(cfar_range_training + 1 : cfar_range_training + 1 + 2 * cfar_range_guard, ...
             cfar_doppler_training + 1 : cfar_doppler_training + 1 + 2 * cfar_doppler_guard) = guard;

    % CFAR parameters
    pfa = cfar_pfa;  % Probability of false alarm
    num_train_cells = sum(p_kernel(:));  % Number of training cells
    alpha = num_train_cells * (pfa ^ (-1 / num_train_cells) - 1);  % Threshold gain
    dims = size(range_doppler_map);  % Get dimensions of range_doppler_map
    kernel = zeros(dims);  % Initialize kernel with zero-padding

    % Square the range_doppler_map
    rdm_power = abs(range_doppler_map).^2;  % Squared magnitude of RD map

    % Zero pad the kernel for FFT
    kernel(1:size(p_kernel,1), 1:size(p_kernel,2)) = p_kernel;
    kernel = kernel / num_train_cells;  % Normalize by number of training cells

    % Perform 2D FFT of the kernel and the range_doppler_map
    mask = fft2(kernel);  % Mask in frequency domain
    noise = ifft2(conj(mask) .* fft2(rdm_power));  % Convolution in frequency domain
    row_shift = floor(size(p_kernel,1) / 2);  % Row shift to account for kernel center
    noise = circshift(noise, row_shift, 1);  % Account for shift introduced by convolution

    % Threshold exceedance (indices where RD map exceeds CFAR threshold)
    indices = rdm_power > (noise * alpha + cfar_threshold);
    detection_indices = find(indices);  % Get detection indices
    detections = zeros(dims);  % Initialize detection map

    % Mark local maximum detections
    detections(detection_indices) = 1;

    % Apply Doppler thresholding to filter out near-zero Doppler values
    doppler_indices = abs(velocityAxis) > minDopplerVelocity;  % Filter out low Doppler (stationary)
    % 
    % % Doppler axis is typically along the first dimension, so expand doppler_indices along range bins
     doppler_mask = repmat(doppler_indices(:), 1, size(range_doppler_map, 2));  % Replicate across the range bins
    % 
    % % Apply the Doppler thresholding to the detections
     detections = detections .* doppler_mask;  % Keep only moving targets

    % Calculate range axis based on range bin size
    rangeAxis = (0:size(range_doppler_map, 2) - 1) * rangeBinSize;  % Range axis in meters

    % Apply range limit to keep only targets within the specified max range
    range_limit_indices = rangeAxis <= maxRange;  % Create a mask for valid ranges

    % Apply the range limit mask to the detections
    range_limit_mask = repmat(range_limit_indices, size(range_doppler_map, 1), 1);  % Replicate along the Doppler dimension
    detections = detections .* range_limit_mask;  % Keep only targets within the range limit
end
