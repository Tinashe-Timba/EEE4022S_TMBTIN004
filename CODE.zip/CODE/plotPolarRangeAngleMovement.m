function plotPolarRangeAngleMovement(anglesMatrix, rangeAngleMap, rangeBinSize, frameIdx, maxRange)
    % Find the indices of the detected targets (where angle values are non-zero)
    [detectedRows, detectedCols] = find(anglesMatrix ~= 0);

    % Extract the angles and ranges for the detected bins
    detectedAngles_deg = anglesMatrix(anglesMatrix ~= 0);  % Detected angles in degrees
    detectedAngles_rad = deg2rad(detectedAngles_deg);  % Convert to radians for polar plotting
    detectedRanges = detectedCols * rangeBinSize;  % Convert range bins to actual range

    % Create a polar scatter plot for detected targets
    figure(4);
    polarscatter(detectedAngles_rad, detectedRanges, 10, 'r', 'filled');
    hold on;

    % Set the limits for the radial (range) axis
    rlim([0 maxRange]);  % Limit the range axis

    % Customize appearance
    set(gca, 'ThetaZeroLocation', 'top');  % Set 0° at the top (forward-facing radar)
    set(gca, 'ThetaDir', 'counterclockwise');  % Set angles to increase counterclockwise

    % Manually adjust angular ticks to show 0° to -90° on the left and 0° to 90° on the right
    ax = gca;
    ax.ThetaTick = [-90 -60 -30 0 30 60 90];  % Use valid tick values within [-90, 90]
    ax.ThetaTickLabel = {'90°', '60°', '30°', '0°', '-30°', '-60°', '-90°'};  % Set the labels properly

    % Limit the angular range to only the upper semicircle (-90° to 90°)
    ax.ThetaLim = [-90 90];  % Show only angles from -90° to 90°
   % colorangle;
    % Set the title
    title(['Polar Range-Angle Plot - Frame ', num2str(frameIdx)]);
     %Add 'Range/m' label as a text annotation
    

   % xlabel('Range/m')
    colormap('jet');  % Use 'jet' colormap (or other like 'parula', 'hot', etc.)    
    % Ensure the plot is updated and displayed
    drawnow;
    hold off;
end
