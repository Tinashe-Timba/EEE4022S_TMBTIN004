% Clear workspace and close all figures
clear all;
close all;

% Specify the HDF5 filenames for both channels and radar parameters 
filename_ch1 = 'Preliminary Testing/PW/tenb7_ch1.hdf5'; % Channel 1 data
filename_ch2 = 'Preliminary Testing/PW/tenb7_ch2.hdf5'; % Channel 2 data
output_folder = 'Preliminary Testing/PW/tenb7';  % Folder to save images for each dataset
mkdir(output_folder);  % Ensure the folder exists

%% PARAMETER LOAD

% FMCW Radar parameters

% FMCW Radar parameters
carrierFrequency = 9.5e9; % Hz, 9.5 GHz carrier frequency
c = 3e8; % Speed of light in meters per second
wavelength = c / carrierFrequency; % Wavelength in meters
antennaDistance = 2.1e-2; % Distance between antennas in meters

rangeBinSize = 1.875; % meters
SRI = 0.0016; % seconds (chirp repetition interval)
numADCSamples = 1024; % Number of ADC samples per chirp 
maxRange = 960.0; % meters
maxDopplerFreq = 625.0; % Hz
maxVelocity = 9.827044025157234; % m/s, calculated based on 9.5 GHz carrier frequency
dopplerBinSize =0.03838689072327044; % Hz
limit =60 ; % Limit3 the range axis to region of interest

% Derived parameters
PRF = 1 / SRI; % Pulse Repetition Frequency
zeroPadLengthRange = 1024; % Zero-padding length for Range FFT
zeroPadLengthDoppler = 256; % Zero-padding length for Doppler FFT
numChirps = 256;
numSamples = 1024;
%% MYCFAR PARAMETERS
% Define CFAR parameters
numGuardCells = 2;
numReferenceCells = 5;
desiredPFA = 1e-6;  % 
%% ADAPTIVE CLUTTER MAP PARAMETERS

initial_alpha = 0.3;  % Initial smoothing factor (0 < alpha < 1)
dynamic_alpha_enabled = true;  % Set to true to enable dynamic adjustment
alpha_min = 0.8;  % Minimum alpha value
alpha_max = 0.9;   % Maximum alpha value
alpha=0.005;

%% %  MMwAVE CFAR function on  rangeDopplerMap
cfar_range_guard = 8;
cfar_range_training = 18;
cfar_doppler_guard = 4;
cfar_doppler_training = 5;
cfar_pfa = 1e-6;
cfar_threshold = 1.8;
minDopplerVelocity = 0.05;
%% % Initialize clutter maps, previous frames, and frame averages


method = 'frame_subtraction'; % Choose between 'adaptive', 'frame_subtraction', 'frame_mean_subtraction'
previousFrame_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
previousFrame_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
clutterMap_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
clutterMap_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
frameMean_A = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
frameMean_B = zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
env1=zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
env2=zeros(zeroPadLengthDoppler,zeroPadLengthRange/2);
%% 
%MICRO DOPPLER PARAMETERS

% Define radar parameters
p.nChirps = 256;

p.nSamples = 1024;
p.PRF=PRF;
p.zeroPadLengthDoppler=zeroPadLengthDoppler;
p.wavelength=wavelength;
p.window_size = 256;
p.overlap = 0.99;
p.pad_size =0;
p.range_bin=256;
p.w_range = 'hann';
p.w_doppler = 'hamming';
%range_bins=10n
%data_all_frames = zeros(numChirps, numADCSamples, TotalFrames);

%% 

% Load information about the datasets for both channels
info_ch1 = h5info(filename_ch1);
info_ch2 = h5info(filename_ch2);
datasets_ch1 = {info_ch1.Datasets.Name};
datasets_ch2 = {info_ch2.Datasets.Name};

% Sort dataset names numerically
datasets_ch1 = sortNumericDatasetNames(datasets_ch1);
datasets_ch2 = sortNumericDatasetNames(datasets_ch2);
TotalFrames = length(datasets_ch1); % Number of frames

% Initialize an array to hold AoA estimates for each frame
AoA_estimates = zeros(1, TotalFrames);

%% 

% Initialize arrays to store preprocessed frames
preprocessed_data_ch1 = [];
preprocessed_data_ch2 = [];

for frameIdx = 1:TotalFrames
    % Load the current dataset (frame) for Channel 1 and Channel 2
    datasetName_ch1 = datasets_ch1{frameIdx};
    datasetName_ch2 = datasets_ch2{frameIdx};
    data_ch1 = h5read(filename_ch1, ['/' datasetName_ch1]).';
    data_ch2 = h5read(filename_ch2, ['/' datasetName_ch2]).';
    
    % Check if the data size is 512x1024 (combined two frames)
    if size(data_ch1, 1) == 512
        % Split into two separate frames of 256x1024
        data_ch1_frame1 = data_ch1(1:256, :);
        data_ch1_frame2 = data_ch1(257:end, :);
        data_ch2_frame1 = data_ch2(1:256, :);
        data_ch2_frame2 = data_ch2(257:end, :);

        % Append the split frames to the preprocessed data array
        preprocessed_data_ch1 = cat(3, preprocessed_data_ch1, data_ch1_frame1, data_ch1_frame2);
        preprocessed_data_ch2 = cat(3, preprocessed_data_ch2, data_ch2_frame1, data_ch2_frame2);

    elseif size(data_ch1, 1) <= 256
        % If the frame is already 256x1024 or smaller, add it directly
        % Pad the frame if necessary (e.g., if it's smaller than 256x1024)
        data_ch1_padded = padarray(data_ch1, [256 - size(data_ch1, 1), 0], 0, 'post');
        data_ch2_padded = padarray(data_ch2, [256 - size(data_ch2, 1), 0], 0, 'post');

        % Append the padded frames to the preprocessed data array
        preprocessed_data_ch1 = cat(3, preprocessed_data_ch1, data_ch1_padded);
        preprocessed_data_ch2 = cat(3, preprocessed_data_ch2, data_ch2_padded);

    elseif size(data_ch1, 1) == 511
        % Handle odd-sized frames like 511x1024 by padding them to 512
        data_ch1_padded = padarray(data_ch1, [1, 0], 0, 'post');
        data_ch2_padded = padarray(data_ch2, [1, 0], 0, 'post');

        % Split into two frames of size 256x1024 after padding
        data_ch1_frame1 = data_ch1_padded(1:256, :);
        data_ch1_frame2 = data_ch1_padded(257:end, :);
        data_ch2_frame1 = data_ch2_padded(1:256, :);
        data_ch2_frame2 = data_ch2_padded(257:end, :);

        % Append the split frames to the preprocessed data array
        preprocessed_data_ch1 = cat(3, preprocessed_data_ch1, data_ch1_frame1, data_ch1_frame2);
        preprocessed_data_ch2 = cat(3, preprocessed_data_ch2, data_ch2_frame1, data_ch2_frame2);

    else
        % Handle any unexpected frame sizes that are not covered
        error('Unexpected frame size: %d-by-%d', size(data_ch1, 1), size(data_ch1, 2));
    end
end

% Update the TotalFrames variable to reflect the actual number of preprocessed frames
TotalFrames = size(preprocessed_data_ch1, 3);
angle_matrix_all_frames = zeros(256, 512, TotalFrames);
p.nFrames = TotalFrames;

% Initialize the 3D matrix to store all frames' data
data_all_frames = zeros(numChirps, numADCSamples, TotalFrames);
refined_cfar_matrix = zeros(zeroPadLengthDoppler, zeroPadLengthRange/2, TotalFrames);

%% 

% Main processing loop for Range-Doppler
for frameIdx = 1:TotalFrames
   
  % Use preprocessed data for Channel 1 and Channel 2 512*1024
    IQ_A = extractIQData(preprocessed_data_ch1(:,:,frameIdx), 16); % Channel 1
    IQ_B = extractIQData(preprocessed_data_ch2(:,:,frameIdx), 16); % Channel 2
    combinedIQ = (IQ_A + IQ_B);
    
    % Store the IQ data for all frames
    % Combine the IQ data from both channels to reduce SNR
    combinedIQ = (IQ_A+IQ_B);
    data_all_frames(:, :, frameIdx) =IQ_A+IQ_B;
    %RANGE FFT
    
   rangeMap_A=computeRangeMap(IQ_A, zeroPadLengthRange);
    
   rangeMap_B=computeRangeMap(IQ_B, zeroPadLengthRange);
   rangeMap_combined = computeRangeMap(combinedIQ, zeroPadLengthRange);

   % rangeMap_A=computeRangeMapSliding(IQ_A, zeroPadLengthRange,512,32);
    
   % rangeMap_B=computeRangeMapSliding(IQ_B, zeroPadLengthRange,512,32);

     % RANGE DOPPLER MAP
    rangeDopplerMap = computeDopplerMap(rangeMap_combined, zeroPadLengthDoppler);
    rangeDopplerMap_a=computeDopplerMap(rangeMap_A, zeroPadLengthDoppler);
    rangeDopplerMap_b=computeDopplerMap(rangeMap_B, zeroPadLengthDoppler);
    % rangeDopplerMap = computeDopplerMapSliding(rangeMap_combined, zeroPadLengthDoppler,128,32);
    % rangeDopplerMap_a=computeDopplerMapSliding(rangeMap_A, zeroPadLengthDoppler,128,32);
    % rangeDopplerMap_b=computeDopplerMapSliding(rangeMap_B, zeroPadLengthDoppler,128,32);



    %CLUTTER REMOVAL
   [rangeDopplerMap_A, rangeDopplerMap_B, clutterMap_A, clutterMap_B, previousFrame_A, previousFrame_B] =  removeClutterMagnitude(rangeDopplerMap_a, rangeDopplerMap_b, previousFrame_A, previousFrame_B, clutterMap_A, clutterMap_B, method, initial_alpha, dynamic_alpha_enabled, alpha_min, alpha_max, frameIdx, alpha,env1,env2);
     

   %CFAR TRAGET DETECTION
    clutterRemovedMap= rangeDopplerMap_A+ (rangeDopplerMap_B);
    velocityAxis = (-size(rangeDopplerMap, 1) / 2 : size(rangeDopplerMap, 1) / 2 - 1) *0.03838689072327044;

   % [CFAR_map, detectedTargets] = detectTargetsWithCFAR(clutterRemovedMap, desiredPFA, numGuardCells, numReferenceCells, velocityAxis);
    detections = cfar(clutterRemovedMap, cfar_range_guard, cfar_range_training, cfar_doppler_guard, cfar_doppler_training, cfar_pfa, cfar_threshold, velocityAxis, minDopplerVelocity, rangeBinSize, 60);

    % Clean up the detections if necessary
    radius =2;  % Example radius
   [refined_cfar, centroid_list] = clean_cfar(detections, radius,abs(clutterRemovedMap));
      refined_cfar_matrix(:, :, frameIdx) =refined_cfar;


    % === Plot and Save Range-Doppler Map ===
    rdFileName = fullfile(output_folder, sprintf('range_doppler_frame_%04d.png', frameIdx));
    %PLOT WITH MY CFAR
    % plotRangeDopplerMapSequence(clutterRemovedMap, frameIdx, maxVelocity, rangeBinSize, limit, PRF, zeroPadLengthDoppler, zeroPadLengthRange, wavelength,detectedTargets,clutterMap);
    %PLOT WITH DETECTIONS MMWAVE
   %plotRangeDopplerMapSequence(clutterRemovedMap, frameIdx, maxVelocity, rangeBinSize, limit, PRF, zeroPadLengthDoppler, zeroPadLengthRange, wavelength,detections,clutterMap);
   %PLOT WITH REFINED CFAR
   plotRangeDopplerMapSequence(clutterRemovedMap, frameIdx, maxVelocity, rangeBinSize, limit, PRF, zeroPadLengthDoppler, zeroPadLengthRange, wavelength,refined_cfar);
    

    saveas(gcf, rdFileName);
    close(gcf);

    % RANGE ANGLE PLOT
    % Compute range-angle map (based on your function)
    %[rangeAngleMap,angleMatrix]=computeRangeAngleMapWithCFAR(rangeDopplerMap_A,rangeDopplerMap_B, zeroPadLengthRange, zeroPadLengthDoppler, carrierFrequency, antennaDistance,detectedTargets);
    [rangeAngleMap,angleMatrix]=computeRangeAngleMapWithCFAR(rangeDopplerMap_a,rangeDopplerMap_b, zeroPadLengthRange, zeroPadLengthDoppler, carrierFrequency, antennaDistance,refined_cfar);
    % Save the Range-Angle Plot
    raFileName = fullfile(output_folder, sprintf('range_angle_frame_%04d.png', frameIdx));
   % plotRangeAngleMap(rangeAngleMap, rangeBinSize, frameIdx);
    % Store the angle matrix for validation
    angle_matrix_all_frames(:, :, frameIdx) = angleMatrix;
   plotPolarRangeAngleMovement(angleMatrix, rangeAngleMap, rangeBinSize, frameIdx,limit )
    %plotRangeAngleMap2(angleMatrix, rangeBinSize, frameIdx)
    saveas(gcf, raFileName);
    close(gcf);
end
%% CREATE VIDEOS

rd_video_file = fullfile(output_folder, 'rd_video.mp4');
generateRangeDopplerVideo(output_folder, rd_video_file, TotalFrames);

ra_video_file = fullfile(output_folder, 'ra_video.mp4');
generateRangeAngleVideo(output_folder, ra_video_file, TotalFrames);
%% %% MICRO DOPPLER PARAMETERS

% Define radar parameters
p.nChirps = 256;
p.nFrames = TotalFrames;
p.nSamples = 1024;
p.PRF=PRF;
p.zeroPadLengthDoppler=zeroPadLengthDoppler;
p.wavelength=wavelength;
p.window_size = 256;
p.overlap = 0.9;
p.pad_size =0;
p.range_bin=256;
p.w_range = 'hann';
p.w_doppler = 'hamming';
v_min= 0;  
v_max =5;
%range_bins=10n
%data_all_frames = zeros(numChirps, numADCSamples, TotalFrames);


%% Micro-Doppler Processing (once all frames are gathered)
% Define the range bins of interest
range_bin_selection = 1:53;  % 

% Call Micro-Doppler function for the entire data matrix

frequency_time = spectrogram_c(data_all_frames, p, v_min, v_max, range_bin_selection, refined_cfar_matrix);


% Normalize the frequency-time matrix
global_max_val = max(abs(frequency_time(:)));
if global_max_val ~= 0
    frequency_time = frequency_time / global_max_val;
end

% Generate and save Micro-Doppler spectrogram image
%microDopplerFileName = fullfile(output_folder, 'microdoppler_spectrogram.png');
%plotMicroDoppler(frequency_time, p, microDopplerFileName);

%% Function to plot and save Micro-Doppler spectrogram
function plotMicroDoppler(frequency_time, p, saveFileName)
    % Find the global maximum value in the entire frequency_time matrix
    global_max_val = max(abs(frequency_time(:)));  % Maximum value of the entire matrix
    
    % Normalize each column of the matrix by the global maximum value
    if global_max_val ~= 0
        frequency_time = frequency_time / global_max_val;  % Normalize the entire matrix
    end

    N = size(frequency_time, 1);
    M = size(frequency_time, 2);
    t_sweep = 0.0016;  % Sweep time
    fs = 1 / t_sweep;
    hop = p.window_size - floor(p.overlap * p.window_size);

    % Time and frequency axes
    time_axis = (p.window_size / 2 : hop : p.window_size / 2 + (M - 1) * hop) / fs;
    dopplerBinSize = 0.03838689072327044;  %doppler bin size
    frequency_axis = (N / 2:-1:-(N / 2)-1) * dopplerBinSize;

    % Plot the Micro-Doppler spectrogram
    figure;
    imagesc(time_axis, frequency_axis, (20 * log10(abs(frequency_time))) - max(max(20 * log10(abs(frequency_time)))));
    title('Micro-Doppler Spectrogram');
    xlabel('Time [s]');
    ylabel('Velocity/(m/s)');
    colorbar;
    caxis([-100 20]); 
    colormap('jet');
    axis xy;  

    saveas(gcf, saveFileName);
    close(gcf);
end


%% Function to generate Range-Doppler Video
function generateRangeDopplerVideo(output_folder, video_filename, TotalFrames)
    videoWriter = VideoWriter(video_filename, 'MPEG-4');
    videoWriter.FrameRate = 1;
    open(videoWriter);

    % Loop over all frame images
    for frameIdx = 1:TotalFrames
        imgFileName = fullfile(output_folder, sprintf('range_doppler_frame_%04d.png', frameIdx));
        if isfile(imgFileName)
            img = imread(imgFileName);
            writeVideo(videoWriter, img);
        end
    end

    close(videoWriter);
end

%% Function to generate Range-Angle Video
function generateRangeAngleVideo(output_folder, video_filename, TotalFrames)
    videoWriter = VideoWriter(video_filename, 'MPEG-4');
    videoWriter.FrameRate = 1;
    open(videoWriter);

    % Loop over all frame images
    for frameIdx = 1:TotalFrames
        imgFileName = fullfile(output_folder, sprintf('range_angle_frame_%04d.png', frameIdx));
        if isfile(imgFileName)
            img = imread(imgFileName);
            writeVideo(videoWriter, img);
        end
    end

    close(videoWriter);
end

