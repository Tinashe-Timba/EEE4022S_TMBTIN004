function [frequency_time] = spectrogram_c(data_all_frames, p, v_min, v_max, range_bin_selection, refined_cfar_all_frames)
    % Initialize micro-Doppler matrix for all frames
    microDopplerMatrix = zeros(p.nChirps, size(data_all_frames, 3));

    % Perform background clutter removal (using the first frame)
    first_frame = data_all_frames(:, :, 1);
    background_fft = fft(first_frame, p.nSamples, 2);
    background_fft = background_fft(:, 1:size(background_fft, 2) / 2);  % Keep positive frequencies
    microDopplerMatrix(:, 1) = (background_fft(:, 1));

    % Process each frame using pre-computed CFAR results
    for frameIdx = 2:size(data_all_frames, 3)  % Start from frame 2 to avoid using the background frame
        % Extract the current frame data
        frame = data_all_frames(:, :, frameIdx);

        % Perform Range FFT for each frame
        range_fft = fft(frame, p.nSamples, 2);
        range_fft = range_fft(:, 1:size(range_fft, 2) / 2);

        % Subtract the background (clutter removal)
        clutter_removed = range_fft - background_fft;

        % Use precomputed CFAR detections for this frame
        cfar_detections = refined_cfar_all_frames(:, :, frameIdx);

        % Find the range bins detected by CFAR 
        detected_range_bins = find(sum(cfar_detections, 1) > 0);
        combined_range_bins = intersect(detected_range_bins, range_bin_selection);

        % Skip processing if no range bins match
        if isempty(combined_range_bins)
            continue;
        end

        % Process only the selected and detected range bins
        clutter_removed = clutter_removed(:, combined_range_bins);

        % Perform Doppler FFT on the selected range bins
        doppler_fft = fftshift(fft(clutter_removed, [], 1), 1);  % Doppler FFT along the 1st dimension (Chirps)

        % Convert Doppler bins to velocities
        doppler_bin_velocity = 0.03838689072327044;
        velocities = ((-size(doppler_fft, 1) / 2 : size(doppler_fft, 1) / 2 - 1)) * doppler_bin_velocity;

        % Select Doppler bins within the desired velocity range
        velocity_mask = (abs(velocities) >= v_min & abs(velocities) <= v_max);

        % Initialize array to store energy for each range bin
        range_bin_energy = zeros(1, size(clutter_removed, 2));

        % Calculate the energy for each range bin based on the selected velocity range
        for r = 1:size(clutter_removed, 2)
            doppler_energy = sum(abs(doppler_fft(velocity_mask, r)).^2);
            range_bin_energy(r) = doppler_energy;
        end

        % Select the range bin with the highest energy that satisfies the velocity condition
        [~, highest_energy_bin] = max(range_bin_energy);

        % Use the range FFT data for the selected range bin
        microDopplerMatrix(:, frameIdx) = (clutter_removed(:, highest_energy_bin));
        highest_energy_bin
    end

    % Reshape microDopplerMatrix into a vector for further processing
    microDopplerVector = reshape(microDopplerMatrix, 1, []);

    % Sliding window and FFT to generate the frequency-time matrix (spectrogram)
    shift = floor(p.window_size * (1 - p.overlap));
    if shift < 1
        shift = 1;
    end

    num_windows = ceil((length(microDopplerVector) - p.window_size) / shift);
    frequency_time = zeros(p.pad_size + p.window_size, num_windows);

    % Apply the sliding window and FFT for each window
    i = 1;
    for n = 1:shift:(length(microDopplerVector) - p.window_size)
        microDopplerWindow = microDopplerVector(n:n + p.window_size - 1);

        % Apply windowing
        if sum(strcmp(p.w_doppler, ["hamming", "blackman", "hann"]))
            w_d = window(p.w_doppler, length(microDopplerWindow));
            microDopplerWindow = microDopplerWindow .* w_d';
        end

        % Zero-pad and compute FFT
        microDopplerWindow = [microDopplerWindow zeros(1, p.pad_size)];
        current_frequency_time = fftshift(fft(microDopplerWindow));

        % Store the result in the frequency_time matrix
        frequency_time(:, i) = current_frequency_time;
        i = i + 1;
    end
end
