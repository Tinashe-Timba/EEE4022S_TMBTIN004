function [rangeAngleMap, anglesMatrix] = computeRangeAngleMapWithCFAR(rangeDopplerMap_A, rangeDopplerMap_B, zeroPadLengthRange, zeroPadLengthDoppler, carrierFrequency, antennaDistance, detectedTargets)
    % Constants
    c = 299792458; % Speed of light (m/s)
    lambda = c / carrierFrequency; % Wavelength (m)
    
    % Initialize range-angle map (for magnitudes)
    [numAngles, numRanges] = size(rangeDopplerMap_A);  % Assuming the same size for both maps
    rangeAngleMap = zeros(numAngles, numRanges);  % Initialize range-angle map (for magnitudes)
    
    % Initialize matrix to store angles
    anglesMatrix = zeros(numAngles, numRanges);  % To store the angles in degrees
    
    % Loop through detected targets and compute AoA only for detected bins
    for rowIdx = 1:numAngles
        for colIdx = 1:numRanges
            if detectedTargets(rowIdx, colIdx) == 1  % Check if CFAR detected a target at this range-Doppler bin
                % Optionally average phase difference over neighboring bins
                phaseDifference = mean(mean(angle(rangeDopplerMap_B(max(rowIdx-1, 1):min(rowIdx+1, numAngles), max(colIdx-1, 1):min(colIdx+1, numRanges)) .* conj(rangeDopplerMap_A(max(rowIdx-1, 1):min(rowIdx+1, numAngles), max(colIdx-1, 1):min(colIdx+1, numRanges))))));

                % Estimate AoA using the phase difference
                avgPhaseDiff = phaseDifference;
                
                % Calculate AoA using phase difference
                argument = avgPhaseDiff * lambda / (2 * pi * antennaDistance);
                argument = max(min(argument, 1), -1);  % Ensure the argument stays within [-1, 1]
                AoA = asin(argument);

                % Convert AoA to degrees
                AoA_deg = rad2deg(AoA);
                
                % Store the reflection magnitude at the detected range-angle bin
                reflectionMagnitude = abs(rangeDopplerMap_A(rowIdx, colIdx));  % Use magnitude for visualization
                
                % Store the reflection magnitude in rangeAngleMap
                rangeAngleMap(rowIdx, colIdx) = reflectionMagnitude;
                
                % Store the corresponding angle in the anglesMatrix
                anglesMatrix(rowIdx, colIdx) = AoA_deg;
            end
        end
    end
end
