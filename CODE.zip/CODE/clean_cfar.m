% function [refined_cfar, centroid_list] = clean_cfar(cfar_map, radius)
%     % Finds clusters within CFAR detections and replaces them with circles at centroids
% 
%     % Find clusters in CFAR map using bwlabel to label connected regions
%     [L, num] = bwlabel(cfar_map);
%     refined_cfar = zeros(size(cfar_map));
%     centroid_list = [];
% 
%     % Loop through each connected region
%     for i = 1:num
%         [row, col] = find(L == i);  % Find all points in the cluster
%         centroid_x = round(mean(col));  % Compute centroid (x-coordinate)
%         centroid_y = round(mean(row));  % Compute centroid (y-coordinate)
%         centroid_list = [centroid_list; centroid_x, centroid_y];  % Store centroid
% 
%         % Create a circular region at the centroid
%         [xx, yy] = meshgrid(1:size(cfar_map, 2), 1:size(cfar_map, 1));
%         circle = ((xx - centroid_x).^2 + (yy - centroid_y).^2) <= radius^2;
%         refined_cfar = refined_cfar + circle;  % Add the circle to the refined map
%     end
% 
%     refined_cfar = min(refined_cfar, 1);  % Ensure refined map is binary (0 or 1)
% end

% function [refined_cfar, centroid_list] = clean_cfar(cfar_map, radius, intensity_map)
%     % Finds clusters within CFAR detections and creates centroids at the strongest points
%     % Only one centroid is created per cluster, based on the highest intensity.
% 
%     % Find clusters in CFAR map using bwlabel to label connected regions
%     [L, num] = bwlabel(cfar_map);
%     refined_cfar = zeros(size(cfar_map));
%     centroid_list = [];
% 
%     % Loop through each connected region (cluster of detections)
%     for i = 1:num
%         [row, col] = find(L == i);  % Find all points in the cluster
% 
%         % Extract intensity values for the points in the cluster
%         intensities = intensity_map(sub2ind(size(intensity_map), row, col));
% 
%         % Find the point with the maximum intensity within the cluster
%         [~, maxIdx] = max(intensities);
% 
%         % Get the coordinates of the strongest point
%         centroid_x = col(maxIdx);
%         centroid_y = row(maxIdx);
% 
%         % Add the strongest point to the centroid list
%         centroid_list = [centroid_list; centroid_x, centroid_y];
% 
%         % Create a circular region at the strongest point (centroid)
%         [xx, yy] = meshgrid(1:size(cfar_map, 2), 1:size(cfar_map, 1));
%         circle = ((xx - centroid_x).^2 + (yy - centroid_y).^2) <= radius^2;
%         refined_cfar = refined_cfar + circle;  % Add the circle to the refined map
%     end
% 
%     refined_cfar = min(refined_cfar, 1);  % Ensure refined map is binary (0 or 1)
% end


function [refined_cfar, centroid_list] = clean_cfar(cfar_map, radius, intensity_map)
    % Refines CFAR detections by selecting only the largest cluster
    % Also adds centroid calculation for the largest cluster based on its size.

    % Find clusters in CFAR map using bwlabel to label connected regions
    [L, num] = bwlabel(cfar_map);
    refined_cfar = zeros(size(cfar_map));
    centroid_list = [];

    if num == 0
        % If no clusters detected, return empty results
        return;
    end

    % Calculate the size of each cluster
    cluster_sizes = arrayfun(@(i) sum(L(:) == i), 1:num);

    % Find the largest cluster
    [~, largest_cluster_idx] = max(cluster_sizes);

    % Extract the largest cluster
    [row, col] = find(L == largest_cluster_idx);

    % Extract intensity values for the points in the largest cluster
    intensities = intensity_map(sub2ind(size(intensity_map), row, col));

    % Find the point with the maximum intensity within the largest cluster
    [~, maxIdx] = max(intensities);

    % Get the coordinates of the strongest point (centroid)
    centroid_x = col(maxIdx);
    centroid_y = row(maxIdx);

    % Add the strongest point (centroid) to the centroid list
    centroid_list = [centroid_list; centroid_x, centroid_y];

    % Create a circular region at the strongest point (centroid)
    [xx, yy] = meshgrid(1:size(cfar_map, 2), 1:size(cfar_map, 1));
    circle = ((xx - centroid_x).^2 + (yy - centroid_y).^2) <= radius^2;

    % Update the refined CFAR map
    refined_cfar = refined_cfar + circle;

    % Ensure the refined CFAR map is binary (0 or 1)
    refined_cfar = min(refined_cfar, 1);
end

% 
% function [refined_cfar, centroid_list] = clean_cfar(cfar_map, radius, intensity_map) 
%     % Refines CFAR detections by focusing on the two largest clusters
%     % Calculates centroids based on intensity.
% 
%     % Find clusters in CFAR map using bwlabel to label connected regions
%     [L, num] = bwlabel(cfar_map);
%     refined_cfar = zeros(size(cfar_map));
%     centroid_list = [];
% 
%     if num == 0
%         % If no clusters detected, return empty results
%         return;
%     end
% 
%     % Calculate the size of each cluster
%     cluster_sizes = arrayfun(@(i) sum(L(:) == i), 1:num);
% 
%     % Sort the clusters by size, and keep the two largest clusters
%     [~, sorted_indices] = sort(cluster_sizes, 'descend');
%     largest_clusters_idx = sorted_indices(1:min(2, num));  % Take the top two clusters, or less if fewer than two clusters
% 
%     % Loop through each of the two largest clusters
%     for i = largest_clusters_idx
%         [row, col] = find(L == i);  % Find all points in the cluster
% 
%         % Extract intensity values for the points in the cluster
%         intensities = intensity_map(sub2ind(size(intensity_map), row, col));
% 
%         % Find the point with the maximum intensity within the cluster
%         [~, maxIdx] = max(intensities);
% 
%         % Get the coordinates of the strongest point (centroid)
%         centroid_x = col(maxIdx);
%         centroid_y = row(maxIdx);
% 
%         % Add the strongest point to the centroid list
%         centroid_list = [centroid_list; centroid_x, centroid_y];
% 
%         % Create a circular region at the strongest point (centroid)
%         [xx, yy] = meshgrid(1:size(cfar_map, 2), 1:size(cfar_map, 1));
%         circle = ((xx - centroid_x).^2 + (yy - centroid_y).^2) <= radius^2;
%         refined_cfar = refined_cfar + circle;  % Add the circle to the refined map
%     end
% 
%     % Ensure the refined CFAR map is binary (0 or 1)
%     refined_cfar = min(refined_cfar, 1);
% end
