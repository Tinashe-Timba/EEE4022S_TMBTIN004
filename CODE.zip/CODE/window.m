    function w = window(window_type, window_length)
    % Create a window based on the input type (hamming, hann, or blackman)
    if strcmp(window_type, 'hamming')
        w = hamming(window_length);  % Hamming window, returns column vector
    elseif strcmp(window_type, 'blackman')
        w = blackman(window_length);  % Blackman window, returns column vector
    elseif strcmp(window_type, 'hann')
        w = hann(window_length);  % Hann window, returns column vector
    else
        error('Invalid window type. Choose "hamming", "blackman", or "hann".');
    end
end
