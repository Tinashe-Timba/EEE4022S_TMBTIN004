% Function to plot Range-Doppler Map for each frame in a sequence
function plotRangeDopplerMapSequence(rangeDopplerMap, frameIdx, maxVelocity, rangeBinSize, limit, PRF, zeroPadLengthDoppler, zeroPadLengthRange, wavelength,detectedTargets)
    % Define the range and Doppler axes
    rangeAxis = (0:size(rangeDopplerMap, 2) - 1) * rangeBinSize;
    velocityAxis = (size(rangeDopplerMap, 1) / 2 - 1:-1:-size(rangeDopplerMap, 1) / 2 ) *0.03838689072327044;%(PRF / zeroPadLengthDoppler) * wavelength/2 ;
   % velocityAxis = (0:size(rangeDopplerMap, 1)-1) *0.03838689072327044 ;
   % velocityAxis = (0:-1:-(size(rangeDopplerMap, 1)-1)) *0.03838689072327044 ;
    figure(1);

    
    imagesc(rangeAxis, velocityAxis, 20 * log10(abs(rangeDopplerMap)/max(max(abs(rangeDopplerMap)))), [-100 0]); % Plot the Range-Doppler map
     %Overlay detected targets with 'x'
     hold on;
    %min_doppler_velocity = 0;
    %detected_targets = find(abs(velocityAxis) > min_doppler_velocity); 
    [targetRows, targetCols] = find(detectedTargets);
    plot(rangeAxis(targetCols), velocityAxis(targetRows), 'rx', 'MarkerSize', 1, 'LineWidth', 2);
    
    xlabel('Range /m');  % Keeps range in meters
    ylabel('Velocity/(m/s)');  % Correct y-label for Doppler velocity
    title(['Range-Doppler Map for Frame ' num2str(frameIdx)]);  % Title including the frame index
    colorbar;  % Show color bar

    axis xy;
    xlim([0 limit]); % Limit the x-axis (range)
    drawnow
    pause(0.1);
end